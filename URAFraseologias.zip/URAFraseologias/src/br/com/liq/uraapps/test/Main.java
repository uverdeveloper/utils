package br.com.liq.uraapps.test;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import br.com.liq.uraapps.bean.Phrases;
import br.com.liq.uraapps.xml.ReadXML;

public class Main {

	public static void main(String[] args) throws IOException{		
		
		String appName = "avi";
		
		Phrases phrasesParam = new Phrases();
//		phrasesParam.setAppName("avi");
		phrasesParam.setIdPromptName("22");
		phrasesParam.setPromptName("0000.wav");
		phrasesParam.setDescription("teste");
		
//		DELETE
		//DeleteTagXML deleteTagXML = new DeleteTagXML(phrases, Integer.parseInt(phrases.getIdPromptName())-1, phrases.getAppName());
		
		
		// UPDATE XML
		
		ReadXML readXML = new ReadXML(appName);

		readXML.readerXML();

		File xml = new File("C:/desenvolvimento/NGR/wildfly-10.1.0.Final/welcome-content/urafraseologias/phrases/avi.xml");
//		System.out.println(xml.getAbsolutePath().substring(0, xml.getAbsolutePath().lastIndexOf(File.separator)));	
		String filePath = xml.getAbsolutePath().substring(0, xml.getAbsolutePath().lastIndexOf(File.separator));
		
			try {
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.parse(xml);

				/*if(item == 0){
					item += 1;
				}*/
				
				Node promptName = doc.getElementsByTagName("promptName").item(22);
				Node description = doc.getElementsByTagName("description").item(22);
				
				promptName.setTextContent(phrasesParam.getPromptName());
				description.setTextContent(phrasesParam.getDescription());

				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource((Node) doc);
				StreamResult result = new StreamResult(new File(xml.toString()));
				transformer.transform(source, result);

			} catch (SAXException | IOException | TransformerException | ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
	}

