package br.com.liq.uraapps.bean;

import java.util.List;

public class Phrases_Control {

	private Phrases phrases;

	public Phrases getPhrases() {
		return phrases;
	}

	public void setPhrases(Phrases phrases) {
		this.phrases = phrases;
	}

	@Override
	public String toString() {
		return "Phrases_Control [phrases=" + phrases + "]";
	}

}
