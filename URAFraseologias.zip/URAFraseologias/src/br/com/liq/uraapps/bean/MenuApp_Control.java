package br.com.liq.uraapps.bean;

public class MenuApp_Control {

	private MenuApp menuApp;

	public MenuApp getMenuApp() {
		return menuApp;
	}

	public void setMenuApp(MenuApp menuApp) {
		this.menuApp = menuApp;
	}

	@Override
	public String toString() {
		return "MenuApp_Control [menuApp=" + menuApp + "]";
	}

}
