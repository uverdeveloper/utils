$.getScript('../js/chooseEnvironment.js', function(){
	url = chooseEnvironment();	
});
	
function newApplicationRegister(){
	
	$("#mensagem").empty();
	
	var appName = $("#appsName").val();
	
	$.ajax(
			{
				type : "POST",
				url : url+"/URAFraseologias/rest/menu/optionsLoad/newApplicationRegister/"+appName,
				contentType : "application/json; charset=UTF-8",
				success : function() {
					location.reload();
				},					
				error : function() {
					$("body").append(
									"<div>"
										+ "<p>"
											+ "<label for=\"msg\" id=\"mensagem\">Internal error.</label>"
										+ "</p>"
									+ "</div>"
									)
								}
			}
		);
	}

function register(){
	
	$("#mensagem").empty();
	
	var appName;
	
	appName = $("#appsName").val();
	
	if($("#idPromptName").val() != ""){
	
	var data = {
				"appName" : appName,
				"idPromptName" : $("#positionPromptName").val(),
				"promptName" : $("#idPromptName").val(),
				"description" : $("#idDescription").val(),
				};
	
			json = JSON.stringify(data);
	
	$.ajax(
			{
				type : "POST",
				url : url+"/URAFraseologias/rest/menu/",
				dataType : "text",
				contentType : "application/json; charset=utf-8",
				data : json,
				success : function(result) {								
					promptDescriptionLoad();
				},
				error : function(erro) {				
					$("body").append(
									"<div>"
										+ "<p>"
											+ "<label for=\"msg\" id=\"mensagem\">Prompt não cadastrado.</label>"
										+ "</p>"
									+ "</div>"
									)
								}
				}
			);
		}else{
			$("body").append(
					"<div>"
						+ "<p style=\"text-align: center\">"
							+ "<label for=\"msg\" id=\"mensagem\">Favor preencher os campos.</label>"
						+ "</p>"
					+ "</div>"
					)
		}
	
	promptDescriptionLoad();
	
	}

function update(positionPromptName,promptName){
	
	promptName = $(promptName).val();
	
	$("#mensagem").empty();
	
	var option = $("#appsName").val();
	
	var data = {
				"idPromptName" : positionPromptName,//$("#positionPromptName").val(), 
				"promptName" : promptName,//$("#idPromptName").val(),
				"description" : $("#idDescription").val(),
				"appName" : $("#appsName").val()
			    };
	
	json = JSON.stringify(data);
	
	alert(json)
	
	$.ajax(
			{
				type : "PUT",
				url : url+"/URAFraseologias/rest/menu/",
				dataType : "text",
				contentType : "application/json; charset=utf-8",
				data : json,
				success : function(result) {
					location.reload();							
				},
				error : function(erro) {				
					$("body").append(
									"<div>"
										+ "<p>"
											+ "<label for=\"msg\" id=\"mensagem\">Prompt não atualizado.</label>"
										+ "</p>"
									+ "</div>"
									)
								}
			}
		);
	}

function deletePrompt(){
	
	$("#mensagem").empty();	
	
	var data = {
				"appName" : $("#appsName").val(),
				"idPromptName" : $("#positionPromptName").val(),
				};
	
	json = JSON.stringify(data);
	
	$.ajax(
			{
				type : "DELETE",
				url : url+"/URAFraseologias/rest/menu/",
				dataType : "text",
				contentType : "application/json; charset=utf-8",
				data : json,
				success : function(result) {
					location.reload();
				},
				error : function(erro) {				
					$("body").append(
									"<div>"
										+ "<p>"
											+ "<label for=\"msg\" id=\"mensagem\">Prompt não apagado.</label>"
										+ "</p>"
									+ "</div>"
									)
								}
			}
		);
	}


	
